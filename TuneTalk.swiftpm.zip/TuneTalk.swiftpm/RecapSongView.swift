import SwiftUI

struct RecapSongView: View {
    @State var isRotating = false
    @State var songNum: Int = 0
    @State var currSong = songs[num]
    @State var firstView = false
    @State var secondView = false
    @State var thirdView = false
    @State var fourthView = false
    

    
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack (alignment: .center){
                HStack (spacing: 4){
                    Text("Recap from the ")
                        .font(.system(size: 50))
                        .bold()
                        .foregroundColor(.white)
                    
                    Text("song lesson")
                        .font(.system(size: 50))
                        .bold()
                        .foregroundColor(.teal)
                }
                .padding()
                .onAppear{
                    
                    currSong = songs[songNum]
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    
                        withAnimation(.easeInOut(duration: 1)) {
                            firstView = true
                        }
                    }
                }
                
                
                
                    Text("If you liked the song lyrics, search the song and listen to it completely! You know what they say, listening to music is one of the best ways to learn a new language! :) ")
                        .font(.title)
                        .italic()
                        .padding(.horizontal, 150)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 20)
                        .padding(.bottom, 15)
            
                HStack (spacing: 40){
                    
                    if firstView{
                        VStack (spacing: 40){
                            VStack (spacing: 15){
                                
                                
                                Text("Song 🎧").bold()
                                    .font(.largeTitle)
                                
                                
                                Text(currSong.name).italic()
                                    .font(.title)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius:10).fill(.red).opacity(0.5))
                                    .cornerRadius(10)
                                
                            }
                            
                            VStack (spacing: 15){
                                Text("Artist 🎤").bold()
                                    .font(.largeTitle)
                                
                                
                                Text(currSong.artist).italic()
                                    .font(.title)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius:10).fill(.orange).opacity(0.5))
                                    .cornerRadius(10)
                            }
                        }.padding(30)
                            .background(.gray.opacity(0.2))
                            .cornerRadius(40)
                            .rotationEffect(Angle(degrees: isRotating ? 360 : 0))
                            .onTapGesture {
                                withAnimation (.easeInOut(duration: 1)){
                                    isRotating.toggle()
                                }
                            }.onAppear{
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                                    
                                    withAnimation(.easeInOut(duration: 1)) {
                                        secondView = true
                                    }
                                }
                            } 
                        
                    }
                    
                    if secondView{
                        VStack (spacing: 40){
                            
                            VStack (spacing: 15){
                                Text("Original Phrase 🇮🇹").bold()
                                    .font(.largeTitle)
                                
                                Text("'\(currSong.lyrics)'")
                                    .italic()
                                    .font(.title)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius:10).fill(.teal).opacity(0.5))
                                    .cornerRadius(10)
                            }
                            
                            VStack (spacing: 15){
                                
                                Text("Translation 🇺🇸").bold()
                                    .font(.largeTitle)
                                
                                
                                Text("'\(currSong.translation)'").italic()
                                    .font(.title)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius:10).fill(.purple).opacity(0.5))
                                    .cornerRadius(10)
                            }
                            
                        }.padding(30)
                            .background(.gray.opacity(0.2))
                            .cornerRadius(40)
                            .onAppear{
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    withAnimation(.easeInOut(duration: 1)) {
                                        thirdView = true
                                    }
                                }
                            }
                    }
                }
                
                if thirdView{
                    VStack{
                        Text("You learned 3 new words! 😛")
                            .font(.largeTitle)
                            .italic()
                            .padding(.top, 30)
                            .bold()
                        
                        HStack (spacing: 30){
                            
                            ForEach(currSong.vocabulary, id: \.self){ word in 
                                
                                NewWord(word: word)
                                
                            }
                            
                        }       
                    }.onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            withAnimation(.easeInOut(duration: 1)) {
                                fourthView = true
                            }
                        }
                    }
                    
                    
                    HStack{
                        Spacer()
                        NavigationLink {
                            SongsView()
                        } label: {
                            
                            Image(systemName: "arrow.right.circle.fill")
                                .font(.system(size: 70))
                                .foregroundColor(.blue)
                                .padding(.horizontal, 60)
                            
                        }
                    }
                }
            }.foregroundColor(.white)
        }
    }
}

struct NewWord: View {
    @State var word: WordPhrase
    var body: some View {
        
        VStack{
            Text(word.it)
                .bold()
                .font(.largeTitle)
            
            Text(word.eng)
                .font(.title2)
                .italic()
        }.padding()
            .background(RoundedRectangle(cornerRadius: 12).fill(.green).opacity(0.5))
            .foregroundColor(.white)
        
    }
}
