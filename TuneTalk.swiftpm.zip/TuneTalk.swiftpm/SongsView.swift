import SwiftUI

struct OneSongView: View {
    var artist: String
    var title: String
    var songNum: Int
    var body: some View {
        NavigationLink {
            ListenView(songNum: songNum)

        } label: {
            HStack{
                
                Text("🎶")
                    .font(.largeTitle)
                    .padding()
                VStack (alignment: .leading){
                    Text(title)
                        .bold()
                        .font(.title)
                        .foregroundColor(.black)
                    
                    Text(artist)
                        .font(.title3)
                        .foregroundColor(.black)
                }
                
                
                Spacer()
                
                SmallAudioPlayer(song: "Song\(songNum+1)")
                    .padding(.trailing)
                
            }.frame(maxWidth: 600)
                .background(.white)
                .cornerRadius(20)


        }
    }
}



struct SongsView: View {
    @State var isPopupPresented: Bool = false
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            NavigationStack{
                VStack (spacing: 20){
                    
                    VStack (spacing: 15){
                        Text("Keep learning with the power of music! 🎷🎧")
                            .font(.system(size: 50))
                            .bold()
                            .foregroundColor(.white)
                        
                        Text("Choose a song to keep practicing. Remember that every song is a different learning journey! 🤩")
                            .font(.title)
                            .italic()
                            .padding(.horizontal, 80)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                    }
                    .padding(.bottom, 20)
                    
                    
                    
                    
                    ForEach(songs) { song in 
                        OneSongView(artist: song.artist, title: song.name, songNum: song.songNum)
                        
                    }
                    
                    
                    HStack (spacing: 15){
                        NavigationLink{
                            GlobalVocabularyView()
                        } label: {
                            Text("My Vocabulary")
                                .font(.title2)
                                .bold()
                                .padding(10)
                                .background(RoundedRectangle(cornerRadius: 10).fill(.indigo).shadow(color:.indigo, radius:5)
                                )
                                .foregroundColor(.white)
                        }
                        
                        Button{
                            isPopupPresented = true
                        } label: {
                            Text("About the Music")
                                .font(.title2)
                                .bold()
                                .padding(10)
                                .background(RoundedRectangle(cornerRadius: 10).fill(.red).shadow(color:.red, radius:5)
                                )
                                .foregroundColor(.white)
                        }
                    }.padding(.top, 20)
                }.sheet(isPresented: $isPopupPresented){
                    PopupMusicView(aboutIsPresented: $isPopupPresented).presentationDetents([.height(900)])}
            }
        }
    }
}

struct PopupMusicView: View {
    @Binding var aboutIsPresented: Bool

    var body: some View {
        ZStack{
            Color.black
            VStack {
                
                Text("About the music used 🎹 🎤")
                    .bold()
                    .font(.largeTitle)
                    Text("All the music featured in TuneTalk is fully sourced from Jamendo, a website that offers music under Creative Commons licenses.  This means that the music is free to use and share, as long as you follow the terms of the specific license that applies to each track, such as not using it for commercial purposes. \n\nThe music used in the app has been created by independent artists who wish to share their work with the world, this is why I also encourage you to check out their work on Jamendo's website if you want to learn more about them and keep practicing the language!. So, by using TuneTalk😎, you're not only learning a new language but also supporting independent and truly talented artists. 🫶🎤.\n\nThe music used in the app includes 3 songs created by independent artists. The artists are listed as follows with their respective songs. \n\n'Il mio mondo' (By: Andrea Bocci) , 'La scelta del presidente' (By: Millionaire Blonde) and 'La mia sola cucciola' (By: Luca Caperna) ")
                        .padding(.horizontal, 50)
                        .font(.headline)
                        .padding(.top)
                        .padding(.bottom, 30)
                
                Button {
                    aboutIsPresented = false
                } label: {
                    Text("Close")
                        .font(.title)
                        .foregroundColor(.teal)
                        .bold()
                }
                
            }.foregroundColor(.white)
                
            
        }
    }
}


