import SwiftUI

struct Word: View {
    var word: String = "hello"
    var body: some View {
        
        VStack{
            Text(word)
                .font(.title2)
                .padding(9)
                .background(.indigo)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        
    }
}





struct DragFinalView: View {
    
    @State var currSong = songs[num]
    @State var droppedWords: [(word: String?, isCorrect: Bool)] = Array(repeating: ("", false), count: songs[num].amountWords)
    @State var draggedWord: String? = nil
    @State var showResults = false
    @State var appearNav = false
    @State var songNum: Int = 0
    @State var showHint = false
    @State var hintsShowed = 0

    
        
    
    var body: some View {
        NavigationStack{
            VStack (spacing: 20){
                

                VStack{
                    Text("Now, try ordering the words that make up the lyrics you just heard.")
                        .font(.title)
                    
                    HStack() {
                        ForEach(songs[songNum].phrase.allWords, id: \.self) { word in
                            Word(word: word)
                                .onDrag({
                                    // When the word is dragged, create a NSItemProvider with the word as plain text
                                    let itemProvider = NSItemProvider(object: word as NSString)
                                    itemProvider.suggestedName = word
                                    return itemProvider
                                })
                        }
                    }
                }.padding(.bottom, 5)
                    .onAppear{
                        droppedWords = Array(repeating: ("", false), count: songs[songNum].amountWords)
                        currSong = songs[songNum]
                    }
                
                Text("Drag them to the following spaces in the right order")
                    .font(.title)
                    .padding(.top)


                
                HStack() {
                    ForEach(droppedWords.indices, id: \.self) { index in
                        let (word, isCorrect) = droppedWords[index]
                        let color = showResults ? (isCorrect ? Color.green.opacity(0.8) : (word != nil ? Color.red.opacity(0.8) : Color.gray.opacity(0.8))) : Color.gray.opacity(0.8)
                        
                        
                        Text(word ?? "")
                            .frame(minWidth: 40, minHeight: 25)
                            .padding(9)
                            .background(color)
                            .foregroundColor(.white)
                            .font(.title2)
                            .cornerRadius(10)
                            .animation(.easeInOut(duration: 0.2), value: word)
                            .onDrop(of: [.text], isTargeted: nil) { providers in
                                let itemProvider = providers.first(where: { $0.hasItemConformingToTypeIdentifier("public.plain-text") })
                                itemProvider?.loadObject(ofClass: NSString.self) { string, _ in
                                    if let word = string as? String {

                                        if let draggedIndex = droppedWords.firstIndex(where: { $0.word == self.draggedWord }) {
                                            droppedWords[draggedIndex].word = nil
                                            droppedWords[draggedIndex].isCorrect = false
                                        }
                                        draggedWord = nil
                                        droppedWords[index].word = word
                                        droppedWords[index].isCorrect = (word == songs[songNum].phrase.rightWords[index])
                                    }
                                }
                                return true
                            }
                            .onDrag({
                                draggedWord = word
                                let itemProvider = NSItemProvider(object: word as! NSString)
                                itemProvider.suggestedName = word
                                return itemProvider
                            })
                            .fixedSize(horizontal: false, vertical: true) // Add this line to make the frame flexible
                        
                    }
                }.padding(.bottom)
                
                

                
                
                
                

                
                HStack (spacing: 20){
                    
                    if !showResults {
                        Button(action: {
                            // Set showResults to true to show the correct/incorrect colors
                            let allWordsCorrect = droppedWords.allSatisfy { $0.isCorrect }
                            
                            if allWordsCorrect {
                                
                                appearNav = true
                                

                                
                            }
                            
                            showResults = true
                            
                            
                        }) {
                            Text("Verify Answers")
                                .padding(10)
                                .font(.title3)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        
                        if !isFullArray(droppedWords) && hintsShowed != 2 {
                            Button {
                                
                                var randomNum = Int.random(in: 0...currSong.amountWords-1)
                                
                                while droppedWords[randomNum].word != "" {
                                    randomNum = Int.random(in: 0...currSong.amountWords-1)
                                }
                                
                                droppedWords[randomNum].word = currSong.phrase.rightWords[randomNum]
                                droppedWords[randomNum].isCorrect = true
                                hintsShowed += 1
                            } label: {
                                Text("Hint 💡")
                                    .padding(10)
                                    .font(.title3)
                                    .background(Color.orange.opacity(0.7))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                            
                        }
                    }
                    

                    
                    
                    if showResults {
                        Button(action: {
                            // Reset the droppedWords array to its initial state
                            droppedWords = Array(repeating: ("", false), count: songs[songNum].amountWords)
                            showResults = false
                            hintsShowed = 0
                        }) {
                            Text("Try Again")
                                .padding(10)
                                .font(.title3)
                                .background(Color.gray.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                    
                    if appearNav {
                        NavigationLink {
                            VocabularyView(songNum: songNum) 
                        } label: {
                            Text("Continue")
                                .font(.title3)
                                .padding(10)
                                .background(.purple)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .bold()
                        }
                    }
                    
                }
                
                if appearNav{
                    Text("That's right! 👏")
                        .bold()
                        .font(.title)
                        .foregroundColor(.green)
                        .padding()
                    
                }
                
                
            }
            .padding()
        }
    }
        
        
    }


func isFullArray(_ array: [(String?, Bool)]) -> Bool {
    
    for element in array {
        if element.0 == ""{
            return false
        }
    }
    
    return true
}
