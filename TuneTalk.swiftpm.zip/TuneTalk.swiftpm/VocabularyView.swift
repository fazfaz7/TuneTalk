import SwiftUI
import AVFoundation
let synthesizer = AVSpeechSynthesizer()

struct VocabularyView: View {
    @State var currSong = songs[num]
    @State var isPopupPresented = false
    @State var popupWordEng = ""
    @State var popupWordIt = ""
    @State var popupEmoji = ""
    @State var lock1: Bool = true
    @State var lock2: Bool = true
    @State var lock3: Bool = true
    @State var showFirstView = false
    @State var showSecondView = false
    @State var showThirdView = false
    @State var isBtn = false
    @State var isScaled = true
    @State var songNum: Int
    
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            NavigationStack {
                VStack (alignment: .center){
                    
                    
                    VStack (alignment: .leading) {
                        
                        Text("Let's break down the lyrics... 📚🎧")
                            .font(.system(size: 50))
                            .bold()
                            .foregroundColor(.white)
                            .padding(.vertical, 15)
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                }
                                withAnimation(.easeInOut(duration: 1)) {
                                    showFirstView = true
                                    currSong = songs[songNum]
                                }
                            }
                        
                        
                        if showFirstView {
                            VStack (alignment: .leading){
                                Text("Your phrase")
                                    .font(.system(size:isScaled ? 37 : 32))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.teal)
                                
                                
                                HStack {
                                    Text("🇮🇹")
                                        .font(.system(size: isScaled ? 60 : 48))
                                    Text("'\(currSong.lyrics)'")
                                        .font(isScaled ? .title : .title2)
                                        .italic()
                                        .padding(.trailing)
                                    
                                    SmallAudioPlayer(song: "Song\(songNum+1)")
                                        
                                    
                                    
                                }.padding(3)
                                    .padding(.horizontal)
                                    .background(RoundedRectangle(cornerRadius: 15).fill(.teal).opacity(0.8))
                                    .foregroundColor(.black)
                                    .padding(.bottom, 20)
                                
                            }
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                                    withAnimation(.easeInOut(duration: 1)) {
                                        showSecondView = true
                                    }
                                }
                            }
                            
                        }
                        
                        if showSecondView{
                            
                            VStack (alignment: .leading){
                                Text("What does it mean?")
                                    .font(.system(size:isScaled ? 37 : 32))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.yellow)
                                
                                HStack {
                                    Text("🇺🇸")
                                        .font(.system(size: isScaled ? 60 : 48))
                                    Text("'\(currSong.translation)'")
                                        .font(isScaled ? .title : .title2)
                                        .italic()
                                    
                                }.padding(3)
                                    .padding(.horizontal)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(.yellow).opacity(0.8))
                                    .foregroundColor(.black)
                                    .padding(.bottom, 50)
                            }.onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                                    withAnimation(.easeInOut(duration: 1)) {
                                        showThirdView = true
                                        isScaled = false
                                    }
                                }
                            }
                        }
                    }
                    
                    
                    
                    if showThirdView {
                        VStack (alignment: .center){
                            Text("Key Vocabulary 📖")
                                .padding(4)
                                .padding(.horizontal)
                                .font(.system(size:35))
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                //.background(RoundedRectangle(cornerRadius: 10).fill(.purple).opacity(0.8))
                                .padding(.bottom, 2)
                            
                            
                            Text("Tap each circle to unlock the meaning of keywords in the lyrics 🥁")
                                .font(.title)
                                .padding()
                                .padding(.bottom)
                                .foregroundColor(.white)
                            
                            HStack (spacing: 45){
                                Circle()
                                    .fill(.gray)
                                    .opacity(0.5)
                                    .frame(maxWidth: 160)
                                    .overlay{
                                        if lock1 {
                                            Image(systemName: "lock.fill")
                                                .foregroundColor(.white)
                                                .font(.system(size: 45))
                                        } else {
                                            Text(currSong.vocabulary[0].emoji)
                                                .font(.system(size: 45))
                                        }
                                        
                                        
                                    }
                                    .onTapGesture {
                                        let word1 = currSong.vocabulary[0]
                                        globalVocabulary.insert(word1)
                                        popupWordEng = word1.eng
                                        popupWordIt = word1.it
                                        popupEmoji = word1.emoji
                                        isPopupPresented = true
                                        lock1 = false
                                    }
                                
                                Circle()
                                    .fill(.gray)
                                    .opacity(0.5)
                                    .frame(maxWidth: 160)
                                    .overlay{
                                        if lock2 {
                                            Image(systemName: "lock.fill")
                                                .foregroundColor(.white)
                                                 .font(.system(size: 45))
                                        } else {
                                            Text(currSong.vocabulary[1].emoji)
                                                 .font(.system(size: 45))
                                        }
                                        
                                    }.onTapGesture {
                                        let word2 = currSong.vocabulary[1]
                                        globalVocabulary.insert(word2)
                                        popupWordEng = word2.eng
                                        popupWordIt = word2.it
                                        popupEmoji = word2.emoji
                                        isPopupPresented = true
                                        lock2 = false
                                    }
                                
                                Circle()
                                    .fill(.gray)
                                    .opacity(0.5)
                                    .frame(maxWidth: 160)
                                    .overlay{
                                        if lock3 {
                                            Image(systemName: "lock.fill")
                                                .foregroundColor(.white)
                                                 .font(.system(size: 45))
                                        } else {
                                            Text(currSong.vocabulary[2].emoji)
                                                 .font(.system(size: 45))
                                        }
                                        
                                        
                                    } .onTapGesture {
                                        let word3 = currSong.vocabulary[2]
                                        globalVocabulary.insert(word3)
                                        popupWordEng = word3.eng
                                        popupWordIt = word3.it
                                        popupEmoji = word3.emoji
                                        isPopupPresented = true
                                        
                                        withAnimation(.easeInOut) {
                                            lock3 = false
                                        }
                                    }
                            }.padding(.bottom)
                        }
                    }
                    
                    
                    
                    if !lock1 && !lock2 && !lock3 {
                        NavigationLink {
                            PronunciationView(songNum: songNum)
                        } label: {
                            Text("Continue")
                                .font(.title3)
                                .padding(14)
                                .background(RoundedRectangle(cornerRadius:15)
                                    .fill(.purple))
                                .foregroundColor(.white)
                        }.padding(.top, 30)
                    }
                        
                    
                }
                .padding()
                .sheet(isPresented: $isPopupPresented){
                    PopupView(isPresented: $isPopupPresented, wordEng: $popupWordEng, wordIt: $popupWordIt, emoji: $popupEmoji).presentationDetents([.height(900)])
                }
                
            }
        }
        
    }
}
 
struct PopupView: View {
    @Binding var isPresented: Bool
    @Binding var wordEng: String
    @Binding var wordIt: String
    @Binding var emoji: String

    var body: some View {
        ZStack{
            Color.black
            VStack {
                Spacer()
                VStack {
                    HStack{
                        Text(wordIt)
                            .font(.system(size: 60))
                            .bold()
                            .padding()
                            .foregroundColor(.white)
                        
                        Button {                            
                            let utterance = AVSpeechUtterance(string: wordIt)
                            utterance.voice = AVSpeechSynthesisVoice(language: "it-IT")
                            utterance.rate = 0.5
                            utterance.volume = 1.0
                            synthesizer.speak(utterance)  
                        } label: {
                            Image(systemName: "speaker.wave.2.fill")
                                .font(.title2)
                                .padding()
                        }
                    }
                
                    
                }
                
                Text(wordEng)
                    .font(.largeTitle)
                    .padding()
                
                Text(emoji)
                    .font(.system(size: 65))
                
                Spacer()
                
                Button {
                    isPresented = false
                } label: {
                    Text("Close")
                        .font(.title)
                        .foregroundColor(.teal)
                        .bold()
                }
                
                Spacer()
                
            }.foregroundColor(.white)
            
        }
    }
}
