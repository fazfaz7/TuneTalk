import Foundation
import SwiftUI

struct Phrase: Identifiable {
    var id = UUID()
    var rightWords: [String]
    var allWords: [String]
}

struct Song: Identifiable {
    var id = UUID()
    var title: String
    var phrase: Phrase
    var duration: Double
    var amountWords: Int
    var lyrics: String
    var translation: String
    var vocabulary: [WordPhrase]
    var songNum: Int
    var artist: String
    var name: String

}

struct WordPhrase: Identifiable, Hashable {
    var id = UUID()
    var eng: String
    var it: String
    var emoji: String
}
/*
var song1 = Song(title: "Song1", phrase: Phrase(rightWords: ["sarà", "che", "hai", "preso", "tutto", "e", "l'hai", "buttato", "via"], allWords: ["sarà", "che", "hai", "mai", "preso", "tutto", "e", "l'hai", "buttato", "malato", "via"].shuffled()), duration: 5, amountWords: 9, lyrics: "Sarà che hai preso tutto e l'hai buttato via", translation: "Maybe you took everything and threw it away", vocabulary: [WordPhrase(eng: "Everything", it: "Tutto", emoji: "💯"), WordPhrase(eng:"Throw away", it:"Buttare via", emoji: "🚮"), WordPhrase(eng: "And", it: "E", emoji:"🔗")], songNum: 0, artist: "Laura Pausini", name: "Frasi a metá")

var song2 = Song(title: "Song2", phrase: Phrase(rightWords: ["cantare", "d'amore", "non", "basta", "mai"], allWords:  ["cantare","ballare","d'amore", "non", "basta", "pasta", "mai"].shuffled()), duration: 10, amountWords: 5, lyrics: "Cantare d'amore non basta mai", translation: "Singing about love is never enough", vocabulary: [WordPhrase(eng: "Love", it: "Amore", emoji: "❤️"), WordPhrase(eng:"To sing", it:"Cantare", emoji: "🎤"), WordPhrase(eng: "Never", it: "Mai", emoji:"🙅‍♀️")], songNum: 1, artist: "Eros Ramazzoti", name: "Piú bella cosa")
*/
var song1 = Song(title: "Song1", 
                 phrase: Phrase(rightWords: ["Tu", "sei", "il", "cuore", "del", "mio", "mondo"], 
                                allWords: ["Tu", "sei", "il", "cuore", "del", "mio", "mondo", "lei", "fragole", "sole", "fondo"].shuffled()), 
                 duration: 8, 
                 amountWords: 7, 
                 lyrics: "Tu sei il cuore del mio mondo", 
                 translation: "You are the heart of my world", 
                 vocabulary: [WordPhrase(eng: "Heart", it: "Cuore", emoji: "♥️"), WordPhrase(eng:"You", it:"Tu", emoji: "🫵"), WordPhrase(eng: "World", it: "Mondo", emoji:"🌍")], 
                 songNum: 0, 
                 artist: "Andrea Bocci", 
                 name: "Il mio mondo")

var song2 = Song(title: "Song2", 
                 phrase: Phrase(rightWords: ["Impossibile", "dormire", "la", "notte", "qui"], 
                                allWords: ["Impossibile", "dormire", "la", "notte", "qui", "vivere", "tutte", "amico"].shuffled()), 
                                duration: 7, 
                 amountWords: 5, 
                 lyrics: "Impossibile dormire la notte qui", 
                 translation: "Impossibile to sleep at night here", 
                 vocabulary: [WordPhrase(eng: "Impossible", it: "Impossibile", emoji: "🚫"), WordPhrase(eng:"Night", it:"Notte", emoji: "🌙"), WordPhrase(eng: "Sleep", it: "Dormire", emoji:"😴")], 
                              songNum: 1, 
                              artist: "Millionaire Blonde", 
                              name: "La Scelta del Presidente")

var song3 = Song(title: "Song3", 
                 phrase: Phrase(rightWords: ["Sei", "tu", "quella", "vita", "che", "continuo", "io", "a", "cercare"], 
                                allWords: ["Sei", "tu", "quella", "vita", "che", "continuo", "io", "a", "cercare"].shuffled()), 
                 duration: 8, 
                 amountWords:9, 
                 lyrics: "Sei tu quella vita che continua io a cercare", 
                 translation: "You are the life that I continue to search for.", 
                 vocabulary: [WordPhrase(eng: "Life", it: "Vita", emoji: "✨"), WordPhrase(eng:"I", it:"Io", emoji: "🙋‍♀️"), WordPhrase(eng: "Search", it: "Cercare", emoji:"🔍")], 
                 songNum: 2, 
                 artist: "Luca Caperna", 
                 name: "La mia sola cucciola")

var songs = [song1, song2, song3]

var num = 0
