import SwiftUI

struct WelcomeView: View {
    
    var body: some View {
        NavigationStack{
            ZStack {
                Color.black
                    .edgesIgnoringSafeArea(.all)
                
                VStack (spacing: 7){
                    HStack{
                        Text("Welcome to ")
     
                        Text("TuneTalk!")
                        .foregroundColor(.teal)
                    }    .bold()
                        .font(Font.custom("AvenirNext-Bold", size: 70))
                        .padding()
                        
                    
                    HStack{
                        Text("My name is Adrián Faz, and I'm a Computer Science student from Mexico 🇲🇽")
                            .font(.title)
                    }.foregroundColor(.white)
                    
                    
                    HStack (spacing: 50){
                        
                        Image("Faz")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 140)
                        
                        Image("FazComputer")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 140)
                            .padding(.bottom, 30)
                        
                        Image("FazHand")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 140)
                        
                    }
                    
                    VStack (alignment: .center){
                        
                        Text("As someone who loves learning new languages, I've discovered that music can be an incredibly powerful tool to keep learning your favorite language.")                           .font(.title)
                            .padding(.horizontal, 120)
                            .multilineTextAlignment(.center)
                        
                        Text("🌎    🎧    🎹")
                            .font(.system(size: 80))
                            .padding()
                        
                        Text("This is how TuneTalk came to life, an app that helps users learn their favorite language through the power of music.")
                            .font(.title)
                            .padding(.horizontal, 120)
                            .multilineTextAlignment(.center)
                        
                    }.foregroundColor(.white)
                    .padding(.bottom, 50)
                    
                    NavigationLink {
                       FactsView() 
                    } label: {
                        Text("Get Started!")
                            .font(.title2)
                            .padding(18)
                            .background(RoundedRectangle(cornerRadius:50)
                                .fill(.indigo))
                            .foregroundColor(.white)
                            .bold()
                    }
                    
                    
                }
                
            }.foregroundColor(.white)
            
        }
    }
}

