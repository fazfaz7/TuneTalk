import SwiftUI
struct FactsView: View {    
        
    @State private var isOneFlipped = false
    @State private var isPhoneFlipped = false
    @State private var isTextVisible = false
    @State private var isThreeFlipped = false

    var body: some View {
        
        NavigationStack {
        
        ZStack {
            
            Color.black
                .edgesIgnoringSafeArea(.all)
        
            VStack {
        
                
                Text("Did you know? 🤔")
                    .font(.system(size: 50))
                    .bold()
                    .padding(.bottom, 40)
                    .foregroundColor(.white)
                
                Text("Tap on each circle to reveal a fact!")
                    .font(.title)
                    .padding(.bottom, 60)
                    .foregroundColor(.white)
                
                HStack (spacing: 50){
                    ZStack{
                        Circle()
                            .fill(.teal)
                            .background(Circle()
                                .fill(.teal)
                                .opacity(0.3)
                                .offset(x:15, y:8))
                            .frame(width: 250)
                            .rotation3DEffect(.degrees(isOneFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0))
                            .scaleEffect(isOneFlipped ? 1.2 : 1.0)
                        
                        Text("🧠")
                            .font(.system(size: 100))
                            .offset(x:0, y: isOneFlipped ? -150 : 0)
                        
                        
                        
                        
                        
                        if isOneFlipped {
                            Text("Studies have shown that listening to music while learning a new language can increase vocabulary retention by up to 30%.")
                                .frame(width:250)
                                .foregroundColor(.black)
                                .font(.title2)
                                .multilineTextAlignment(.center)
                                .padding(20)
                                .padding(.top, 15)
                                .animation(Animation.easeInOut(duration: 0.5).delay(0.5))
                                .transition(.opacity)
                                .onAppear {
                                    withAnimation {
                                        isTextVisible = true
                                    }
                                }
                            
                            
                        }
                    }.onTapGesture {
                        withAnimation(.easeInOut) {
                            isOneFlipped.toggle()
                        }
                    }
                    
                    ZStack{
                        Circle()
                            .fill(.indigo)
                            .background(Circle()
                                .fill(.indigo)
                                .opacity(0.3)
                                .offset(x:15, y:8))
                            .frame(width: 250)
                            .rotation3DEffect(.degrees(isPhoneFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0))
                            .scaleEffect(isPhoneFlipped ? 1.2 : 1.0)
                        
                        Text("🎧")
                            .font(.system(size: 100))
                            .offset(x:0, y: isPhoneFlipped ? -150 : 0)
                        
                        if isPhoneFlipped {
                            Text("Singing helps improve pronunciation and accent assimilation, which is essential to sound like a native speaker.")
                                .frame(width:250)
                                .foregroundColor(.black)
                                .font(.title2)
                                .multilineTextAlignment(.center)
                                .padding(20)
                                .padding(.top, 15)
                                .animation(Animation.easeInOut(duration: 0.5).delay(0.5))
                                .transition(.opacity)
                                .onAppear {
                                    withAnimation {
                                        isTextVisible = true
                                    }
                                }
                        }
                        
                    }.onTapGesture {
                        withAnimation(.easeInOut) {
                            isPhoneFlipped.toggle()
                        }
                    }
                    
                    
                    ZStack{
                        Circle()
                            .fill(.yellow)
                            .background(Circle()
                                .fill(.yellow)
                                .opacity(0.3)
                                .offset(x:15, y:8))
                            .frame(width: 250)
                            .rotation3DEffect(.degrees(isThreeFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0))
                            .scaleEffect(isThreeFlipped ? 1.2 : 1.0)
                        
                        
                        Text("✅")
                            .font(.system(size: 100))
                            .offset(x:0, y: isThreeFlipped ? -150 : 0)
                        
                        if isThreeFlipped {
                            Text("Daily practice and exposure to the language with music can be more effective than focusing on grammatical rules. ")
                                .frame(width:250)
                                .foregroundColor(.black)
                                .font(.title2)
                                .multilineTextAlignment(.center)
                                .padding(20)
                                .animation(Animation.easeInOut(duration: 0.5).delay(0.5))
                                .transition(.opacity)
                                .onAppear {
                                    withAnimation {
                                        isTextVisible = true
                                    }
                                }
                            
                            
                        }
                        
                    }.onTapGesture {
                        withAnimation(.easeInOut) {
                            isThreeFlipped.toggle()
                        }
                    }
                    
                }.padding(.bottom, 120)
                
                NavigationLink {
                    ListenView(songNum: num) 
                } label: {
                    Text("Start learning!")
                        .font(.title2)
                        .padding(18)
                        .background(RoundedRectangle(cornerRadius:50)
                            .fill(.purple))
                        .foregroundColor(.white)
                        .bold()
                }
                
                }
                
                
            }
                
                
            
       
        }.navigationBarBackButtonHidden(true)
    }
}
