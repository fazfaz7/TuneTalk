import SwiftUI
import AVFoundation


struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        
        
        //#-learning-code-snippet(4.customShape)
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
                
        
        return path
    }
}


struct AudioPlayer: View {
        
    @State var audioPlayer: AVAudioPlayer?
    @State var isPlaying: Bool = false
    @State var song: String?
    @State var isSongPlayed: Bool = false
    
    var body: some View {
        VStack{
            HStack{
                Button {
                    
                    if isPlaying {
                        audioPlayer?.stop()
                    } else {
                        
                        do {
                            guard let fileURL = Bundle.main.url(forResource: song, withExtension: "mp3") else {
                                return
                            }
                           
                            // Create an instance of AVAudioPlayer with your file URL
                            audioPlayer = try AVAudioPlayer(contentsOf: fileURL)
                            
                            // Set properties on your audio player if desired
                            audioPlayer?.volume = 0.5 // 0.0 = silent, 1.0 = full volume
                            audioPlayer?.numberOfLoops = 0 // 0 = play once, -1 = loop indefinitely
                            // Start playing the audio
                            audioPlayer?.play()
                            
                            
                            
                            
                            
                            isSongPlayed.toggle()
                        } catch {
                            print("Error playing audio: \(error)")
                        }
                    }
                    
                    isPlaying.toggle()
                    
                    
                } label: {
                
                    if isPlaying {
                        Rectangle()
                            .frame(maxWidth: 40)
                            .padding(20)
                            .padding(.leading, 10)
                            
                    } else {
                        Triangle()
                            .frame(maxWidth: 40)
                            .padding(20)
                            .padding(.leading, 10)

                    }

                    
                }.foregroundColor(.white)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: 80)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.indigo)
            )

            .padding()
            .padding(.horizontal, 100)

            
        }
    }
}


    

        
        
