import SwiftUI

var globalVocabulary: Set<WordPhrase> = []

struct GlobalVocabularyView: View{
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        
        VStack (spacing: 20){
            
            Text("Your vocabulary 📒")
                .font(.system(size: 50))
                .bold()
                .padding(.bottom)
                .padding(.top)
            
            Text("These are all of the words that you have learned until now! 😝")
                .font(.title)
                .italic()
                .foregroundColor(.white)
                .padding()
            
            ScrollView{
                VStack (spacing: 30){
                    
                    ForEach(Array(globalVocabulary)) { word in 
                        HStack{
                            Text(word.emoji)
                                .font(.system(size: 45))
                                .padding(.trailing)
                            
                            VStack (alignment: .leading){
                                Text(word.it)
                                    .font(.title)
                                    .bold()
                                Text(word.eng)
                                    .font(.title2)
                                    .italic()
                            }
                            
                            
                        }
                        .padding()
                        .frame(minWidth: 200, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 10).fill(.indigo))
                    }
                    
                }
            }
        }.foregroundColor(.white)
        }
        
    }
}





