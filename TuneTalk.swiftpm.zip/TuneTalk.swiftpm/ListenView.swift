import SwiftUI

struct ListenView: View {
    @State var isSongPlayed = false
    @State var songListened: Bool = false
    @State var displayTest: Bool = false
    @State var songDuration: Double = 0.0
    @State private var isAnimating = false
    @State var songNum: Int
    @State var currSong = songs[num]

    var body: some View {    
        
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack{
                
                Text("First time listening... 🥸🎧")
                    .font(.system(size: 50))
                    .bold()
                    .foregroundColor(.white)
                    .padding(.vertical, 10)
                    .onAppear{
                        currSong = songs[songNum]
                    }
                
    
                
                VStack{
                    
                    HStack{
                        Text("Listen to the following piece of track...")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        
                        
                        CirclePlayer(song: "Song\(songNum+1)").onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + songs[songNum].duration){
                                displayTest = true
                            }
                        }
                        .padding(15)
                    }
                    

                }
                
                if displayTest {
                    
                    Divider()
                    
                    DragFinalView(songNum: songNum)
                        .animation(.easeIn(duration: 3), value: isAnimating)
                        .opacity(isAnimating ? 1 : 0)
                        .onAppear {
                            withAnimation {
                                isAnimating = true
                            }      
                            
                        }

                }
                
                VStack{/*
                    Text("Song: \(currSong.name) - \(currSong.artist)")
                        .font(.title)
                        .padding(7)
                        .background(RoundedRectangle(cornerRadius: 10).fill(.purple).opacity(0.5))
                        .bold()
                        */
                    Text("Music tracks sourced by Jamendo Music.")
                        .font(.title2)
                }.padding(.top, 25)
                
            }.foregroundColor(.white)
        }
    }
}
