import SwiftUI
import AVFoundation

struct SmallAudioPlayer: View {
    
    @State var audioPlayer: AVAudioPlayer?
    @State var isPlaying: Bool = false
    @State var song: String?
    @State var isSongPlayed: Bool = false
    
    var body: some View {
        VStack{
            HStack{
                Button {
                    
                    if isPlaying {
                        audioPlayer?.play()
                    } else {
                        
                        do {
                            guard let fileURL = Bundle.main.url(forResource: song, withExtension: "mp3") else {
                                return
                            }
                            
                            // Create an instance of AVAudioPlayer with your file URL
                            audioPlayer = try AVAudioPlayer(contentsOf: fileURL)
                            
                            // Set properties on your audio player if desired
                            audioPlayer?.volume = 0.5 // 0.0 = silent, 1.0 = full volume
                            audioPlayer?.numberOfLoops = 0 // 0 = play once, -1 = loop indefinitely
                            // Start playing the audio
                            audioPlayer?.play()
                            
                            
                            
                            
                            
                            isSongPlayed.toggle()
                        } catch {
                            print("Error playing audio: \(error)")
                        }
                    }
                    
                    isPlaying.toggle()
                    
                    
                } label: {
                    
                    if isPlaying {
                        
                        Image(systemName: "speaker.wave.2.fill")
                            .foregroundColor(.black)
                            .font(.title3)
                        
                        
                        
                        
                    } else {
                        
                        Image(systemName: "speaker.wave.2.fill")
                            .foregroundColor(.black)
                            .font(.title3)
                        
                        
                        
                    }
                    
                    
                }
            }
            
            
            
            
        }
    }
}






