import SwiftUI
import AVFoundation

struct CirclePlayer: View {
    
    @State var audioPlayer: AVAudioPlayer?
    @State var isPlaying: Bool = false
    @State var song: String?
    @State var isSongPlayed: Bool = false
    
    var body: some View {
        VStack{
            HStack{
                Button {
                    
                    if isPlaying {
                        audioPlayer?.play()
                    } else {
                        
                        do {
                            guard let fileURL = Bundle.main.url(forResource: song, withExtension: "mp3") else {
                                return
                            }
                            
                            // Create an instance of AVAudioPlayer with your file URL
                            audioPlayer = try AVAudioPlayer(contentsOf: fileURL)
                            
                            audioPlayer?.volume = 0.5 
                            audioPlayer?.numberOfLoops = 0 
                            audioPlayer?.play()
                            
                            isSongPlayed.toggle()
                            
               
                        } catch {
                            print("Error playing audio: \(error)")
                        }
                    }
                    
                    isPlaying.toggle()
                    
                    
                } label: {
                    
                    if isPlaying {
                        
                        
                        Circle()
                            .fill(.blue)
                            .frame(width: 50)
                            .opacity(0.6)
                            .overlay{
                                Image(systemName: "speaker.wave.3.fill")
                                    .foregroundColor(.white)
                                    .font(.title2)
                            }
                        
                    } else {
                        
                        Circle()
                            .fill(.blue)
                            .frame(width: 50)
                            .opacity(0.75)
                            .overlay{
                                Image(systemName: "speaker.wave.3.fill")
                                    .foregroundColor(.white)
                                    .font(.title2)
                            }

                        
                        
                    }
                    
                    
                }
            }
            
            
            
            
        }
    }
}






