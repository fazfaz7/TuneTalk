import SwiftUI

struct PronunciationView: View {
    
    @StateObject private var viewModel = SpeechViewModel()
    @State var control: Bool = false
    @State var savedMessage: String = ""
    @State var currSong = songs[num]
    @State var songNum: Int = num
    @State var isRecording: Bool = false
    @State private var pulse: CGFloat = 1
    @State private var attempts: Int = 0
    @State private var showGiveUp: Bool = false
    @State private var firstTime: Bool = false
    
    
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            NavigationStack{
                VStack (spacing: 10){
                    Spacer()
                    Text("Now it's your turn! 🗣️ 🫵")  
                        .font(.system(size: 50))
                        .bold()
                        .padding()
                    
                    HStack{
                        Text("First, listen to the lyrics one more time...")
                            .font(.title)
                            .padding()
                            .padding(.trailing)
                        
                        CirclePlayer(song: "Song\(songNum+1)")
                    }.onAppear{
                        currSong = songs[songNum]
                    }
                    
                    Divider()
                    
                    VStack{
                        
                        Text("Ready? Now try pronouncing the phrase yourself!")
                            .font(.title)
                            .padding()
                        
                        Text("'\(currSong.lyrics)'")
                            .font(.title)
                            .italic()
                            .foregroundColor(.teal)
                            .bold()
                            .padding()
                        /*
                            .onAppear{
                                /*#-code-walkthrough(7.heartPulse)*/
                                withAnimation(.easeInOut.repeatForever(autoreverses: true)) {
                                    pulse = 1.1 * pulse
                                }
                            }
                         */
                    }
                    
                    HStack{
                        Button {
                            if viewModel.recognitionTask == nil {
                                viewModel.startRecording()
                                print("RECORD")
                                isRecording = true                               
                                print(attempts)
                                
                            } else {
                                savedMessage = viewModel.recognizedText 
                                viewModel.stopRecording()
                                print(savedMessage)
                                print("STOP")
                                isRecording = false
                                firstTime = true
                                firstTime = true
                                attempts+=1
                                control = true
                                viewModel.recognitionTask = nil
                                
                            }
                        } label: {
                            ZStack{
                                Circle()
                                    .fill(.teal)
                                    .opacity(0.5)
                                    .frame(width:80)
                                
                                Image(systemName: isRecording ? "square.fill" : "mic.fill")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                            }
                            .padding(20)
                        }
                        
            
                    }
                    
                    HStack{
                        
                        VStack{
                            Text("You said...")
                                .padding(.bottom,5)
                            
                            
                            
                            if control {
                                Text(savedMessage)
                                    .italic()
                                    .font(.title2)
                                
                            } 
                        }
                    
                        
                    }
                        
                                                            
                    
                    if savedMessage.lowercased() == currSong.lyrics.lowercased()  {
                        Text("Great Job!")
                            .foregroundColor(.green)
                            .font(.title)
                            .bold()
                        
          
                        NavigationLink {
                            RecapSongView(songNum: songNum)
                        } label: {
                            Text("See Results!")
                                .font(.title3)
                                .padding(10)
                                .background(.purple)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .bold()
                                .padding()
                        }
                        
                        
                    } else if savedMessage != "" && savedMessage.lowercased() != currSong.lyrics.lowercased() || firstTime && (savedMessage.lowercased() != currSong.lyrics.lowercased()){
                        Text("Try again...")
                            .foregroundColor(.red)
                            .font(.title2)
                            .bold()
        
                    }
                    
                    if attempts >= 3{
                        NavigationLink {
                            
                            RecapSongView(songNum: songNum)
                            
                        } label: {
                            Text("Give up? 😮")
                                .font(.title3)
                                .padding(10)
                                .background(.gray.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .bold()
                                .padding()
                        }
                    }
                    
                    
                    Spacer()
                    
                }
            }
            
        }.foregroundColor(.white)
        .onAppear{
            currSong = songs[songNum]
        }
    }
}
